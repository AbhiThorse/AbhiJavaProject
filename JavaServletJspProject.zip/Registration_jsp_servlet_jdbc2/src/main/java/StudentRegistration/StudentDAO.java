package StudentRegistration;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import DatabaseConnection.DBConnection;
import StudentModel.Student;


public class StudentDAO {
	 public boolean registerStudent(Student student) {
	        String query = "INSERT INTO students (name, email, password, course) VALUES (?, ?, ?, ?)";
	        try (Connection conn = DBConnection.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(query)) {
	            pstmt.setString(1, student.getName());
	            pstmt.setString(2, student.getEmail());
	            pstmt.setString(3, student.getPassword());
	            pstmt.setString(4, student.getCourse());
	            return pstmt.executeUpdate() > 0; // Returns true if inserted successfully
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	 }
}
